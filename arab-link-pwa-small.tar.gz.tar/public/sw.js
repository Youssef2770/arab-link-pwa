const CACHE_NAME = 'arab-link-v1';
const STATIC_CACHE = 'arab-link-static-v1';
const DATA_CACHE = 'arab-link-data-v1';

// Assets to cache
const STATIC_FILES = [
  '/',
  '/static/js/bundle.js',
  '/static/css/main.css',
  '/manifest.json',
  '/images/icon.jpg',
  '/images/icon.jpg'
];

// API endpoints to cache
const DATA_URLS = [
  '/api/businesses',
  '/api/categories',
  '/api/reviews'
];

// Install Service Worker
self.addEventListener('install', (event) => {
  console.log('[SW] Install');
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => {
        console.log('[SW] Pre-caching offline page');
        return cache.addAll(STATIC_FILES);
      })
      .then(() => {
        self.skipWaiting();
      })
  );
});

// Activate Service Worker
self.addEventListener('activate', (event) => {
  console.log('[SW] Activate');
  event.waitUntil(
    caches.keys().then((keyList) => {
      return Promise.all(keyList.map((key) => {
        if (key !== STATIC_CACHE && key !== DATA_CACHE) {
          console.log('[SW] Removing old cache', key);
          return caches.delete(key);
        }
      }));
    })
  );
  self.clients.claim();
});

// Fetch Strategy
self.addEventListener('fetch', (event) => {
  console.log('[SW] Fetch', event.request.url);
  
  // Handle API calls
  if (event.request.url.includes('/api/')) {
    event.respondWith(
      caches.open(DATA_CACHE).then((cache) => {
        return fetch(event.request)
          .then((response) => {
            // If request is successful, clone and cache the response
            if (response.status === 200) {
              cache.put(event.request.url, response.clone());
            }
            return response;
          })
          .catch((err) => {
            // Network failed, try to serve from cache
            return cache.match(event.request);
          });
      })
    );
    return;
  }

  // Handle static assets
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Return cached version or fetch from network
        return response || fetch(event.request);
      })
      .catch(() => {
        // Show offline page for navigation requests
        if (event.request.destination === 'document') {
          return caches.match('/');
        }
      })
  );
});

// Background Sync (for future implementation)
self.addEventListener('sync', (event) => {
  console.log('[SW] Background sync', event.tag);
  if (event.tag === 'background-sync') {
    event.waitUntil(doBackgroundSync());
  }
});

function doBackgroundSync() {
  // Sync offline data when connection is restored
  return Promise.resolve();
}

// Push notifications (for future implementation)
self.addEventListener('push', (event) => {
  console.log('[SW] Push received');
  const options = {
    body: event.data ? event.data.text() : 'New update available!',
    icon: '/images/icon.jpg',
    badge: '/icons/icon-72x72.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'explore',
        title: 'Open App',
        icon: '/images/icon.jpg'
      },
      {
        action: 'close',
        title: 'Close',
        icon: '/images/icon.jpg'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('Arab Link', options)
  );
});

// Handle notification clicks
self.addEventListener('notificationclick', (event) => {
  console.log('[SW] Notification click received.');
  
  event.notification.close();
  
  if (event.action === 'explore') {
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});