import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Building2, 
  FolderTree, 
  MessageSquare, 
  Megaphone,
  Star,
  TrendingUp
} from 'lucide-react';
import { getAdminStats, getBusinesses, getReviews } from '@/lib/storage';
import AdminLayout from '@/components/Admin/AdminLayout';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  const stats = getAdminStats();
  const recentBusinesses = getBusinesses().slice(-5).reverse();
  const recentReviews = getReviews().slice(-5).reverse();

  const statCards = [
    {
      title: 'Total Businesses',
      value: stats.totalBusinesses,
      description: `${stats.featuredBusinesses} featured`,
      icon: Building2,
      color: 'text-blue-600'
    },
    {
      title: 'Categories',
      value: stats.totalCategories,
      description: 'Active categories',
      icon: FolderTree,
      color: 'text-green-600'
    },
    {
      title: 'Reviews',
      value: stats.totalReviews,
      description: 'Customer reviews',
      icon: MessageSquare,
      color: 'text-purple-600'
    },
    {
      title: 'Ad Banners',
      value: stats.activeBanners,
      description: `${stats.totalBanners} total`,
      icon: Megaphone,
      color: 'text-orange-600'
    }
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600">Manage your Arab Link platform</p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {statCards.map((stat) => {
            const Icon = stat.icon;
            return (
              <Card key={stat.title}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                  <Icon className={`h-4 w-4 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <p className="text-xs text-muted-foreground">{stat.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Manage your platform efficiently</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Link to="/admin/businesses">
                <Button className="w-full" variant="outline">
                  <Building2 className="mr-2 h-4 w-4" />
                  Manage Businesses
                </Button>
              </Link>
              <Link to="/admin/categories">
                <Button className="w-full" variant="outline">
                  <FolderTree className="mr-2 h-4 w-4" />
                  Manage Categories
                </Button>
              </Link>
              <Link to="/admin/ads">
                <Button className="w-full" variant="outline">
                  <Megaphone className="mr-2 h-4 w-4" />
                  Manage Ads
                </Button>
              </Link>
              <Button className="w-full" variant="outline">
                <TrendingUp className="mr-2 h-4 w-4" />
                View Analytics
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Businesses */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Businesses</CardTitle>
              <CardDescription>Latest business registrations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentBusinesses.map((business) => (
                  <div key={business.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-medium">{business.name}</h4>
                      <p className="text-sm text-gray-600">{business.category}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      {business.featured && <Badge variant="secondary">Featured</Badge>}
                      {business.verified && <Badge variant="default">Verified</Badge>}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Reviews */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Reviews</CardTitle>
              <CardDescription>Latest customer feedback</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentReviews.map((review) => (
                  <div key={review.id} className="p-3 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{review.userName}</h4>
                      <div className="flex items-center">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="ml-1 text-sm">{review.rating}</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 truncate">{review.comment}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboard;