import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, Edit, Trash2, Eye, EyeOff } from 'lucide-react';
import { getAdBanners, addAdBanner, updateAdBanner, deleteAdBanner, getBusinesses } from '@/lib/storage';
import AdminLayout from '@/components/Admin/AdminLayout';
import { toast } from 'sonner';
import { AdBanner } from '@/types';

const AdminAds = () => {
  const [banners, setBanners] = useState(getAdBanners());
  const [businesses] = useState(getBusinesses());
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState<AdBanner | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    imageUrl: '',
    linkUrl: '',
    businessId: '',
    isActive: true
  });

  const refreshBanners = () => {
    setBanners(getAdBanners());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim() || !formData.description.trim()) {
      toast.error('Title and description are required');
      return;
    }

    const bannerData = {
      title: formData.title,
      description: formData.description,
      imageUrl: formData.imageUrl || '/api/placeholder/800/200',
      linkUrl: formData.linkUrl || undefined,
      businessId: formData.businessId || undefined,
      isActive: formData.isActive
    };

    if (editingBanner) {
      // Update existing banner
      const updated = updateAdBanner(editingBanner.id, bannerData);
      
      if (updated) {
        toast.success('Banner updated successfully');
        setIsEditDialogOpen(false);
        setEditingBanner(null);
        refreshBanners();
      }
    } else {
      // Add new banner
      addAdBanner(bannerData);
      toast.success('Banner added successfully');
      setIsAddDialogOpen(false);
      refreshBanners();
    }

    setFormData({
      title: '',
      description: '',
      imageUrl: '',
      linkUrl: '',
      businessId: '',
      isActive: true
    });
  };

  const handleEdit = (banner: AdBanner) => {
    setEditingBanner(banner);
    setFormData({
      title: banner.title,
      description: banner.description,
      imageUrl: banner.imageUrl,
      linkUrl: banner.linkUrl || '',
      businessId: banner.businessId || '',
      isActive: banner.isActive
    });
    setIsEditDialogOpen(true);
  };

  const handleDelete = (bannerId: string) => {
    if (window.confirm('Are you sure you want to delete this banner?')) {
      const success = deleteAdBanner(bannerId);
      if (success) {
        toast.success('Banner deleted successfully');
        refreshBanners();
      } else {
        toast.error('Failed to delete banner');
      }
    }
  };

  const toggleActive = (bannerId: string) => {
    const banner = banners.find(b => b.id === bannerId);
    if (banner) {
      const updated = updateAdBanner(bannerId, { isActive: !banner.isActive });
      if (updated) {
        toast.success(`Banner ${updated.isActive ? 'activated' : 'deactivated'}`);
        refreshBanners();
      }
    }
  };

  const BannerForm = () => (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="title">Banner Title</Label>
        <Input
          id="title"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          placeholder="Featured Business or Promotion"
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Brief description of the promotion"
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="imageUrl">Image URL</Label>
        <Input
          id="imageUrl"
          value={formData.imageUrl}
          onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
          placeholder="/images/banner.jpg (optional)"
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="businessId">Link to Business (optional)</Label>
        <Select value={formData.businessId} onValueChange={(value) => setFormData({ ...formData, businessId: value })}>
          <SelectTrigger>
            <SelectValue placeholder="Select a business" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">No specific business</SelectItem>
            {businesses.map((business) => (
              <SelectItem key={business.id} value={business.id}>
                {business.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="linkUrl">Custom Link URL (optional)</Label>
        <Input
          id="linkUrl"
          value={formData.linkUrl}
          onChange={(e) => setFormData({ ...formData, linkUrl: e.target.value })}
          placeholder="https://example.com (optional)"
        />
      </div>
      
      <div className="flex items-center space-x-2">
        <Switch
          id="isActive"
          checked={formData.isActive}
          onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
        />
        <Label htmlFor="isActive">Active Banner</Label>
      </div>
      
      <Button type="submit" className="w-full">
        {editingBanner ? 'Update Banner' : 'Add Banner'}
      </Button>
    </form>
  );

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Advertising Management</h1>
            <p className="text-gray-600">Manage promotional banners and advertisements</p>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Banner
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Banner</DialogTitle>
                <DialogDescription>
                  Create a promotional banner for the homepage
                </DialogDescription>
              </DialogHeader>
              <BannerForm />
            </DialogContent>
          </Dialog>
        </div>

        {/* Active Banner Preview */}
        <Card>
          <CardHeader>
            <CardTitle>Active Banners Preview</CardTitle>
            <CardDescription>How banners appear on the homepage</CardDescription>
          </CardHeader>
          <CardContent>
            {banners.filter(b => b.isActive).map((banner) => (
              <div key={banner.id} className="mb-4 p-4 border rounded-lg bg-gradient-to-r from-blue-50 to-indigo-50">
                <img 
                  src={banner.imageUrl} 
                  alt={banner.title}
                  className="w-full h-32 object-cover rounded-lg mb-3"
                />
                <h3 className="text-lg font-semibold">{banner.title}</h3>
                <p className="text-gray-600">{banner.description}</p>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Banners Table */}
        <Card>
          <CardHeader>
            <CardTitle>All Banners ({banners.length})</CardTitle>
            <CardDescription>Manage all advertising banners</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Linked Business</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {banners.map((banner) => {
                  const linkedBusiness = banner.businessId 
                    ? businesses.find(b => b.id === banner.businessId)
                    : null;
                    
                  return (
                    <TableRow key={banner.id}>
                      <TableCell>
                        <div className="font-medium">{banner.title}</div>
                      </TableCell>
                      <TableCell>
                        <div className="max-w-xs truncate">{banner.description}</div>
                      </TableCell>
                      <TableCell>
                        {linkedBusiness ? (
                          <Badge variant="outline">{linkedBusiness.name}</Badge>
                        ) : (
                          <span className="text-gray-400">No link</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={banner.isActive ? "default" : "secondary"}>
                          {banner.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => toggleActive(banner.id)}
                          >
                            {banner.isActive ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(banner)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(banner.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Banner</DialogTitle>
              <DialogDescription>
                Update banner details and settings
              </DialogDescription>
            </DialogHeader>
            <BannerForm />
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
};

export default AdminAds;