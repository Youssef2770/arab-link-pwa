import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Edit, Trash2, Star, MapPin } from 'lucide-react';
import { getBusinesses, updateBusiness, getBusiness } from '@/lib/storage';
import AdminLayout from '@/components/Admin/AdminLayout';
import { toast } from 'sonner';

const AdminBusinesses = () => {
  const [businesses, setBusinesses] = useState(getBusinesses());
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBusiness, setSelectedBusiness] = useState(null);

  const filteredBusinesses = businesses.filter(business =>
    business.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    business.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    business.city.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const toggleFeatured = (businessId: string) => {
    const business = getBusiness(businessId);
    if (business) {
      const updated = updateBusiness(businessId, { featured: !business.featured });
      if (updated) {
        setBusinesses(getBusinesses());
        toast.success(`Business ${updated.featured ? 'featured' : 'unfeatured'} successfully`);
      }
    }
  };

  const toggleVerified = (businessId: string) => {
    const business = getBusiness(businessId);
    if (business) {
      const updated = updateBusiness(businessId, { verified: !business.verified });
      if (updated) {
        setBusinesses(getBusinesses());
        toast.success(`Business ${updated.verified ? 'verified' : 'unverified'} successfully`);
      }
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Business Management</h1>
            <p className="text-gray-600">Manage all businesses on the platform</p>
          </div>
        </div>

        {/* Search and Filters */}
        <Card>
          <CardHeader>
            <CardTitle>Search & Filter</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex space-x-4">
              <Input
                placeholder="Search businesses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
          </CardContent>
        </Card>

        {/* Businesses Table */}
        <Card>
          <CardHeader>
            <CardTitle>All Businesses ({filteredBusinesses.length})</CardTitle>
            <CardDescription>Manage business listings, verification, and featured status</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Business Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBusinesses.map((business) => (
                  <TableRow key={business.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{business.name}</div>
                        <div className="text-sm text-gray-600">{business.subcategory}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{business.category}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1 text-gray-400" />
                        {business.city}, {business.country}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                        {business.rating} ({business.reviewCount})
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-1">
                        {business.verified && (
                          <Badge variant="default" className="text-xs">Verified</Badge>
                        )}
                        {business.featured && (
                          <Badge variant="secondary" className="text-xs">Featured</Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleFeatured(business.id)}
                        >
                          {business.featured ? 'Unfeature' : 'Feature'}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleVerified(business.id)}
                        >
                          {business.verified ? 'Unverify' : 'Verify'}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminBusinesses;