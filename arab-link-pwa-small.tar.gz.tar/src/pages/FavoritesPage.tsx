import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Heart, Search } from 'lucide-react';
import { Header } from '@/components/Layout/Header';
import { BusinessCard } from '@/components/Business/BusinessCard';
import { getFavorites, getBusinesses, getCurrentUser } from '@/lib/storage';
import { Business } from '@/types';

export default function FavoritesPage() {
  const [favoriteBusinesses, setFavoriteBusinesses] = useState<Business[]>([]);
  const [loading, setLoading] = useState(true);
  const user = getCurrentUser();

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const favoriteIds = getFavorites();
    const allBusinesses = getBusinesses();
    const favorites = allBusinesses.filter(business => favoriteIds.includes(business.id));
    setFavoriteBusinesses(favorites);
    setLoading(false);
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex items-center justify-center py-20">
          <div className="animate-pulse text-lg">Loading...</div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <Heart className="h-16 w-16 text-gray-400 mx-auto mb-6" />
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Sign In Required</h1>
          <p className="text-xl text-gray-600 mb-8">
            Please sign in to view your favorite businesses.
          </p>
          <Button asChild>
            <Link to="/">Sign In</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Favorites</h1>
          <p className="text-gray-600">
            {favoriteBusinesses.length} favorite business{favoriteBusinesses.length !== 1 ? 'es' : ''}
          </p>
        </div>

        {favoriteBusinesses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favoriteBusinesses.map((business) => (
              <BusinessCard key={business.id} business={business} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <Heart className="h-16 w-16 text-gray-400 mx-auto mb-6" />
            <h2 className="text-2xl font-bold text-gray-900 mb-4">No Favorites Yet</h2>
            <p className="text-gray-600 mb-8 max-w-md mx-auto">
              Start exploring and add businesses to your favorites by clicking the heart icon.
            </p>
            <Button asChild>
              <Link to="/search">
                <Search className="h-4 w-4 mr-2" />
                Browse Businesses
              </Link>
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}