import { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Filter, Grid, List } from 'lucide-react';
import { Header } from '@/components/Layout/Header';
import { BusinessCard } from '@/components/Business/BusinessCard';
import { SearchFilters } from '@/components/Search/SearchFilters';
import { getBusinesses } from '@/lib/storage';
import { Business, SearchFilters as SearchFiltersType, CATEGORIES } from '@/types';

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState('relevance');
  
  const [filters, setFilters] = useState<SearchFiltersType>({
    category: searchParams.get('category') || undefined,
    city: searchParams.get('city') || undefined,
    rating: searchParams.get('rating') ? parseInt(searchParams.get('rating')!) : undefined,
    priceRange: searchParams.get('priceRange')?.split(',') || undefined,
    isOpen: searchParams.get('isOpen') === 'true' || undefined,
  });

  const businesses = getBusinesses();

  // Filter and search businesses
  const filteredBusinesses = useMemo(() => {
    let result = [...businesses];

    // Text search
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(business =>
        business.name.toLowerCase().includes(query) ||
        business.description.toLowerCase().includes(query) ||
        business.category.toLowerCase().includes(query) ||
        business.subcategory.toLowerCase().includes(query) ||
        business.city.toLowerCase().includes(query) ||
        business.country.toLowerCase().includes(query)
      );
    }

    // Apply filters
    if (filters.category) {
      result = result.filter(business => business.category === filters.category);
    }

    if (filters.city) {
      result = result.filter(business => business.city === filters.city);
    }

    if (filters.rating) {
      result = result.filter(business => business.rating >= filters.rating!);
    }

    if (filters.priceRange?.length) {
      result = result.filter(business => filters.priceRange!.includes(business.priceRange));
    }

    if (filters.isOpen) {
      result = result.filter(business => {
        const now = new Date();
        const day = now.toLocaleDateString('en-US', { weekday: 'long' });
        const currentHours = business.hours[day];
        
        if (!currentHours || currentHours === 'Closed') return false;
        
        try {
          const currentTime = now.getHours() * 100 + now.getMinutes();
          const [openTime, closeTime] = currentHours.split(' - ').map(time => {
            const [hour, minute] = time.replace(/[^\d:]/g, '').split(':').map(Number);
            const isPM = time.toLowerCase().includes('pm');
            const adjustedHour = isPM && hour !== 12 ? hour + 12 : (!isPM && hour === 12 ? 0 : hour);
            return adjustedHour * 100 + (minute || 0);
          });
          
          return currentTime >= openTime && currentTime <= closeTime;
        } catch {
          return false;
        }
      });
    }

    // Sort results
    switch (sortBy) {
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'reviews':
        result.sort((a, b) => b.reviewCount - a.reviewCount);
        break;
      case 'name':
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'newest':
        result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      default: // relevance
        // Featured businesses first, then by rating
        result.sort((a, b) => {
          if (a.featured && !b.featured) return -1;
          if (!a.featured && b.featured) return 1;
          return b.rating - a.rating;
        });
    }

    return result;
  }, [businesses, searchQuery, filters, sortBy]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const newParams = new URLSearchParams(searchParams);
    if (searchQuery.trim()) {
      newParams.set('q', searchQuery.trim());
    } else {
      newParams.delete('q');
    }
    setSearchParams(newParams);
  };

  const handleFiltersChange = (newFilters: SearchFiltersType) => {
    setFilters(newFilters);
    const newParams = new URLSearchParams(searchParams);
    
    // Update URL params
    Object.entries(newFilters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        if (Array.isArray(value) && value.length > 0) {
          newParams.set(key, value.join(','));
        } else if (!Array.isArray(value)) {
          newParams.set(key, value.toString());
        }
      } else {
        newParams.delete(key);
      }
    });
    
    setSearchParams(newParams);
  };

  const handleClearFilters = () => {
    setFilters({});
    setSearchParams(new URLSearchParams({ q: searchQuery }));
  };

  // Update search query from URL
  useEffect(() => {
    const query = searchParams.get('q') || '';
    setSearchQuery(query);
  }, [searchParams]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <form onSubmit={handleSearch} className="flex-1 relative">
              <Input
                type="text"
                placeholder="Search businesses, doctors, restaurants..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 text-lg"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            </form>
            <Button type="submit" onClick={handleSearch} className="px-8">
              Search
            </Button>
          </div>

          {/* Results Info and Controls */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                {searchQuery ? `Search results for "${searchQuery}"` : 'All Businesses'}
              </h1>
              <p className="text-gray-600">
                {filteredBusinesses.length} business{filteredBusinesses.length !== 1 ? 'es' : ''} found
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              <SearchFilters 
                filters={filters} 
                onFiltersChange={handleFiltersChange}
                onClearFilters={handleClearFilters}
              />
              
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevance">Relevance</SelectItem>
                  <SelectItem value="rating">Highest Rating</SelectItem>
                  <SelectItem value="reviews">Most Reviews</SelectItem>
                  <SelectItem value="name">Name A-Z</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="flex items-center border rounded-lg">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Results */}
        {filteredBusinesses.length > 0 ? (
          <div className={`grid gap-6 ${
            viewMode === 'grid' 
              ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' 
              : 'grid-cols-1'
          }`}>
            {filteredBusinesses.map((business) => (
              <BusinessCard key={business.id} business={business} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-24 h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
              <Search className="h-12 w-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">No businesses found</h3>
            <p className="text-gray-600 mb-6">
              Try adjusting your search criteria or filters to find what you're looking for.
            </p>
            <Button onClick={handleClearFilters} variant="outline">
              Clear Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}