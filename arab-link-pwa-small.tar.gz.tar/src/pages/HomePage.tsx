import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, MapPin, Star, TrendingUp, Users, Building2 } from 'lucide-react';
import { Header } from '@/components/Layout/Header';
import { BusinessCard } from '@/components/Business/BusinessCard';
import { getBusinesses } from '@/lib/storage';
import { CATEGORIES } from '@/types';
import AdBanner from '@/components/AdBanner';

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState('');
  const businesses = getBusinesses();
  
  const featuredBusinesses = useMemo(() => 
    businesses.filter(b => b.featured).slice(0, 6), [businesses]
  );
  
  const topRatedBusinesses = useMemo(() =>
    businesses
      .filter(b => b.rating >= 4.5)
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 6), [businesses]
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/search?q=${encodeURIComponent(searchQuery.trim())}`;
    }
  };

  const stats = [
    { icon: Building2, label: 'Businesses', value: '5,000+' },
    { icon: Users, label: 'Happy Customers', value: '50,000+' },
    { icon: MapPin, label: 'European Cities', value: '100+' },
    { icon: Star, label: 'Average Rating', value: '4.8' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Advertising Banner */}
      <div className="container mx-auto px-4 pt-8">
        <AdBanner />
      </div>
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-green-600 to-blue-600 text-white py-20">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Connect with Arabic Businesses
            <span className="block text-green-200">Across Europe</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-green-100 max-w-3xl mx-auto">
            Your premier platform connecting you with over 5,000 trusted Arabic-speaking businesses, 
            professionals, and services throughout Europe.
          </p>
          
          {/* Hero Search */}
          <div className="max-w-2xl mx-auto">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="Search for doctors, restaurants, services..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-14 pl-6 pr-20 text-lg bg-white text-gray-900 border-0 rounded-full shadow-lg"
              />
              <Button 
                type="submit"
                className="absolute right-2 top-2 h-10 px-6 bg-green-600 hover:bg-green-700 rounded-full"
              >
                <Search className="h-5 w-5" />
              </Button>
            </form>
          </div>
          
          {/* Popular Searches */}
          <div className="mt-8 flex flex-wrap justify-center gap-2">
            <span className="text-green-200 mr-2">Popular:</span>
            {['Doctors', 'Restaurants', 'Legal Services', 'Halal Food'].map((term) => (
              <Link key={term} to={`/search?q=${encodeURIComponent(term)}`}>
                <Badge variant="secondary" className="bg-white/20 text-white hover:bg-white/30 cursor-pointer">
                  {term}
                </Badge>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-lg mb-4">
                  <stat.icon className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Explore Categories
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Find Arabic businesses and services across all categories
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {Object.entries(CATEGORIES).map(([key, category]) => (
              <Link key={key} to={`/search?category=${key}`}>
                <Card className="h-full hover:shadow-lg transition-all duration-200 cursor-pointer group">
                  <CardHeader className="text-center">
                    <div className="w-12 h-12 mx-auto mb-4 bg-gradient-to-r from-green-600 to-blue-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Building2 className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-lg group-hover:text-blue-600 transition-colors">
                      {category.name}
                    </CardTitle>
                    <CardDescription>
                      {category.subcategories.length} subcategories
                    </CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Businesses */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Featured Businesses</h2>
              <p className="text-gray-600">Discover top-rated Arabic businesses</p>
            </div>
            <Link to="/search?featured=true">
              <Button variant="outline">
                View All
                <TrendingUp className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredBusinesses.map((business) => (
              <BusinessCard key={business.id} business={business} />
            ))}
          </div>
        </div>
      </section>

      {/* Top Rated Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Top Rated</h2>
              <p className="text-gray-600">Highly recommended by our community</p>
            </div>
            <Link to="/search?rating=4">
              <Button variant="outline">
                View All
                <Star className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {topRatedBusinesses.map((business) => (
              <BusinessCard key={business.id} business={business} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-green-600 to-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Own a Business?
          </h2>
          <p className="text-xl mb-8 text-green-100">
            Join thousands of Arabic business owners who have found success through our platform.
          </p>
          <Link to="/register-business">
            <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100">
              List Your Business
              <Building2 className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <img 
                  src="/logo.png" 
                  alt="Arab Link Logo" 
                  className="w-8 h-8 object-contain"
                />
                <span className="text-xl font-bold">Arab Link</span>
              </div>
              <p className="text-gray-400 mb-4">
                The premier platform connecting Arabic communities with trusted businesses and services across Europe.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/search" className="hover:text-white">Browse Businesses</Link></li>
                <li><Link to="/categories" className="hover:text-white">Categories</Link></li>
                <li><Link to="/register-business" className="hover:text-white">Add Business</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/help" className="hover:text-white">Help Center</Link></li>
                <li><Link to="/contact" className="hover:text-white">Contact Us</Link></li>
                <li><Link to="/privacy" className="hover:text-white">Privacy Policy</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Arab Link. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}