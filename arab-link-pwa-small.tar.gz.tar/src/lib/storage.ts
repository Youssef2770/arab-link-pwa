import { Business, Review, User } from '@/types';

const STORAGE_KEYS = {
  BUSINESSES: 'dalilk_businesses',
  USERS: 'dalilk_users',
  REVIEWS: 'dalilk_reviews',
  CURRENT_USER: 'dalilk_current_user',
  FAVORITES: 'dalilk_favorites'
};

// Initialize with sample data
const initializeSampleData = () => {
  if (!localStorage.getItem(STORAGE_KEYS.BUSINESSES)) {
    const sampleBusinesses: Business[] = [
      {
        id: '1',
        name: 'Al-Nour Medical Center',
        category: 'healthcare',
        subcategory: 'General Practice',
        description: 'Arabic-speaking doctors providing comprehensive healthcare services for the Arab community in London.',
        address: '123 Edgware Road',
        city: 'London',
        country: 'United Kingdom',
        phone: '+44 20 1234 5678',
        email: 'info@alnour-medical.co.uk',
        website: 'https://alnour-medical.co.uk',
        hours: {
          'Monday': '9:00 AM - 6:00 PM',
          'Tuesday': '9:00 AM - 6:00 PM',
          'Wednesday': '9:00 AM - 6:00 PM',
          'Thursday': '9:00 AM - 6:00 PM',
          'Friday': '9:00 AM - 6:00 PM',
          'Saturday': '10:00 AM - 4:00 PM',
          'Sunday': 'Closed'
        },
        rating: 4.8,
        reviewCount: 127,
        priceRange: '$$',
        images: ['/api/placeholder/400/300'],
        featured: true,
        verified: true,
        createdAt: '2024-01-15T10:00:00Z',
        updatedAt: '2024-08-20T15:30:00Z',
        latitude: 51.5174,
        longitude: -0.1611
      },
      {
        id: '2',
        name: 'Maroush Restaurant',
        category: 'restaurants',
        subcategory: 'Lebanese',
        description: 'Authentic Lebanese cuisine in the heart of Paris. Family-owned restaurant serving traditional dishes.',
        address: '45 Rue de la Paix',
        city: 'Paris',
        country: 'France',
        phone: '+33 1 42 86 87 88',
        email: 'contact@maroush-paris.fr',
        hours: {
          'Monday': '12:00 PM - 11:00 PM',
          'Tuesday': '12:00 PM - 11:00 PM',
          'Wednesday': '12:00 PM - 11:00 PM',
          'Thursday': '12:00 PM - 11:00 PM',
          'Friday': '12:00 PM - 12:00 AM',
          'Saturday': '12:00 PM - 12:00 AM',
          'Sunday': '12:00 PM - 10:00 PM'
        },
        rating: 4.6,
        reviewCount: 89,
        priceRange: '$$$',
        images: ['/api/placeholder/400/300'],
        featured: true,
        verified: true,
        createdAt: '2024-02-10T14:20:00Z',
        updatedAt: '2024-08-18T09:15:00Z',
        latitude: 48.8698,
        longitude: 2.3316
      },
      {
        id: '3',
        name: 'Al-Hakeem Law Firm',
        category: 'legal',
        subcategory: 'Immigration Law',
        description: 'Specialized immigration law firm helping Arab families navigate European immigration processes.',
        address: 'Kurfürstendamm 200',
        city: 'Berlin',
        country: 'Germany',
        phone: '+49 30 1234 5678',
        email: 'info@al-hakeem-law.de',
        website: 'https://al-hakeem-law.de',
        hours: {
          'Monday': '9:00 AM - 5:00 PM',
          'Tuesday': '9:00 AM - 5:00 PM',
          'Wednesday': '9:00 AM - 5:00 PM',
          'Thursday': '9:00 AM - 5:00 PM',
          'Friday': '9:00 AM - 4:00 PM',
          'Saturday': 'By Appointment',
          'Sunday': 'Closed'
        },
        rating: 4.9,
        reviewCount: 156,
        priceRange: '$$$$',
        images: ['/api/placeholder/400/300'],
        featured: false,
        verified: true,
        createdAt: '2024-01-20T11:45:00Z',
        updatedAt: '2024-08-19T16:20:00Z',
        latitude: 52.5029,
        longitude: 13.3359
      },
      {
        id: '4',
        name: 'Barakah Halal Market',
        category: 'retail',
        subcategory: 'Halal Food',
        description: 'Complete halal grocery store with fresh meat, vegetables, and Middle Eastern specialties.',
        address: 'Gran Vía 45',
        city: 'Madrid',
        country: 'Spain',
        phone: '+34 91 123 4567',
        email: 'info@barakah-market.es',
        hours: {
          'Monday': '8:00 AM - 9:00 PM',
          'Tuesday': '8:00 AM - 9:00 PM',
          'Wednesday': '8:00 AM - 9:00 PM',
          'Thursday': '8:00 AM - 9:00 PM',
          'Friday': '8:00 AM - 9:00 PM',
          'Saturday': '8:00 AM - 9:00 PM',
          'Sunday': '9:00 AM - 8:00 PM'
        },
        rating: 4.5,
        reviewCount: 78,
        priceRange: '$$',
        images: ['/api/placeholder/400/300'],
        featured: false,
        verified: true,
        createdAt: '2024-03-05T08:30:00Z',
        updatedAt: '2024-08-21T12:10:00Z',
        latitude: 40.4200,
        longitude: -3.7025
      },
      {
        id: '5',
        name: 'Dr. Ahmed Dental Clinic',
        category: 'healthcare',
        subcategory: 'Dentistry',
        description: 'Modern dental clinic with Arabic-speaking staff. Comprehensive dental care for all ages.',
        address: 'Via Roma 150',
        city: 'Rome',
        country: 'Italy',
        phone: '+39 06 1234 5678',
        email: 'info@ahmed-dental.it',
        website: 'https://ahmed-dental.it',
        hours: {
          'Monday': '9:00 AM - 6:00 PM',
          'Tuesday': '9:00 AM - 6:00 PM',
          'Wednesday': '9:00 AM - 6:00 PM',
          'Thursday': '9:00 AM - 6:00 PM',
          'Friday': '9:00 AM - 5:00 PM',
          'Saturday': '9:00 AM - 1:00 PM',
          'Sunday': 'Closed'
        },
        rating: 4.7,
        reviewCount: 92,
        priceRange: '$$$',
        images: ['/api/placeholder/400/300'],
        featured: true,
        verified: true,
        createdAt: '2024-02-28T13:15:00Z',
        updatedAt: '2024-08-20T10:45:00Z',
        latitude: 41.9028,
        longitude: 12.4964
      }
    ];
    localStorage.setItem(STORAGE_KEYS.BUSINESSES, JSON.stringify(sampleBusinesses));

    const sampleReviews: Review[] = [
      {
        id: '1',
        businessId: '1',
        userId: 'user1',
        userName: 'Omar Hassan',
        rating: 5,
        comment: 'Excellent service! Dr. Ali speaks perfect Arabic and made me feel very comfortable. Highly recommended!',
        createdAt: '2024-08-15T14:30:00Z',
        helpful: 12
      },
      {
        id: '2',
        businessId: '2',
        userId: 'user2',
        userName: 'Fatima Al-Zahra',
        rating: 5,
        comment: 'Best Lebanese food in Paris! The hummus and tabbouleh are just like my grandmother used to make.',
        createdAt: '2024-08-10T19:45:00Z',
        helpful: 8
      },
      {
        id: '3',
        businessId: '3',
        userId: 'user3',
        userName: 'Ahmed Mahmoud',
        rating: 5,
        comment: 'Mr. Al-Hakeem helped me with my visa application. Professional and knowledgeable. Saved me so much time!',
        createdAt: '2024-08-05T11:20:00Z',
        helpful: 15
      }
    ];
    localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(sampleReviews));
  }
};

// Business operations
export const getBusinesses = (): Business[] => {
  initializeSampleData();
  const businesses = localStorage.getItem(STORAGE_KEYS.BUSINESSES);
  return businesses ? JSON.parse(businesses) : [];
};

export const getBusiness = (id: string): Business | null => {
  const businesses = getBusinesses();
  return businesses.find(b => b.id === id) || null;
};

export const addBusiness = (business: Omit<Business, 'id' | 'createdAt' | 'updatedAt'>): Business => {
  const businesses = getBusinesses();
  const newBusiness: Business = {
    ...business,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  businesses.push(newBusiness);
  localStorage.setItem(STORAGE_KEYS.BUSINESSES, JSON.stringify(businesses));
  return newBusiness;
};

export const updateBusiness = (id: string, updates: Partial<Business>): Business | null => {
  const businesses = getBusinesses();
  const index = businesses.findIndex(b => b.id === id);
  if (index === -1) return null;
  
  businesses[index] = { ...businesses[index], ...updates, updatedAt: new Date().toISOString() };
  localStorage.setItem(STORAGE_KEYS.BUSINESSES, JSON.stringify(businesses));
  return businesses[index];
};

// Review operations
export const getReviews = (businessId?: string): Review[] => {
  initializeSampleData();
  const reviews = localStorage.getItem(STORAGE_KEYS.REVIEWS);
  const allReviews = reviews ? JSON.parse(reviews) : [];
  return businessId ? allReviews.filter((r: Review) => r.businessId === businessId) : allReviews;
};

export const addReview = (review: Omit<Review, 'id' | 'createdAt'>): Review => {
  const reviews = getReviews();
  const newReview: Review = {
    ...review,
    id: Date.now().toString(),
    createdAt: new Date().toISOString()
  };
  reviews.push(newReview);
  localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(reviews));
  
  // Update business rating
  updateBusinessRating(review.businessId);
  
  return newReview;
};

const updateBusinessRating = (businessId: string) => {
  const reviews = getReviews(businessId);
  const business = getBusiness(businessId);
  if (!business) return;
  
  const avgRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length;
  updateBusiness(businessId, { rating: Math.round(avgRating * 10) / 10, reviewCount: reviews.length });
};

// User operations
export const getCurrentUser = (): User | null => {
  const user = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
  return user ? JSON.parse(user) : null;
};

export const loginUser = (email: string, password: string): User | null => {
  // Simple mock authentication
  const mockUser: User = {
    id: 'user1',
    name: email.split('@')[0],
    email,
    isBusinessOwner: false,
    favorites: [],
    reviews: [],
    createdAt: new Date().toISOString()
  };
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(mockUser));
  return mockUser;
};

export const registerUser = (name: string, email: string, password: string, isBusinessOwner: boolean = false): User => {
  const user: User = {
    id: Date.now().toString(),
    name,
    email,
    isBusinessOwner,
    favorites: [],
    reviews: [],
    createdAt: new Date().toISOString()
  };
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  return user;
};

export const logoutUser = () => {
  localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
};

interface SocialLoginData {
  id: string;
  name: string;
  email: string;
  picture?: string;
  photoURL?: string;
  uid?: string;
}

export const socialLogin = (provider: 'google' | 'facebook', socialData: SocialLoginData): User => {
  const user: User = {
    id: Date.now().toString(),
    name: socialData.name,
    email: socialData.email,
    password: '', // Social users don't have passwords
    isBusinessOwner: false,
    avatar: socialData.picture || socialData.photoURL || '',
    socialProvider: provider,
    socialId: socialData.id || socialData.uid,
    favorites: [],
    reviews: [],
    createdAt: new Date().toISOString()
  };
  
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  return user;
};

// Favorites operations
export const getFavorites = (): string[] => {
  const user = getCurrentUser();
  return user?.favorites || [];
};

export const addToFavorites = (businessId: string): void => {
  const user = getCurrentUser();
  if (user && !user.favorites.includes(businessId)) {
    user.favorites.push(businessId);
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  }
};

export const removeFromFavorites = (businessId: string): void => {
  const user = getCurrentUser();
  if (user) {
    user.favorites = user.favorites.filter(id => id !== businessId);
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  }
};

export const isFavorite = (businessId: string): boolean => {
  const favorites = getFavorites();
  return favorites.includes(businessId);
};
// Admin authentication
export const loginAdmin = (email: string, password: string): User | null => {
  // Default admin credentials
  if (email === 'admin@arablink.com' && password === 'admin123') {
    const adminUser: User = {
      id: 'admin',
      name: 'Admin',
      email: 'admin@arablink.com',
      isBusinessOwner: false,
      isAdmin: true,
      favorites: [],
      reviews: [],
      createdAt: new Date().toISOString()
    };
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(adminUser));
    return adminUser;
  }
  return null;
};

export const isCurrentUserAdmin = (): boolean => {
  const user = getCurrentUser();
  return user?.isAdmin === true;
};

// Category management
export const getCategories = (): Category[] => {
  initializeSampleData();
  const categories = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
  return categories ? JSON.parse(categories) : [];
};

export const addCategory = (name: string, subcategories: string[] = []): Category => {
  const categories = getCategories();
  const newCategory: Category = {
    id: Date.now().toString(),
    name,
    subcategories,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  categories.push(newCategory);
  localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  return newCategory;
};

export const updateCategory = (id: string, updates: Partial<Category>): Category | null => {
  const categories = getCategories();
  const index = categories.findIndex(c => c.id === id);
  if (index === -1) return null;
  
  categories[index] = { ...categories[index], ...updates, updatedAt: new Date().toISOString() };
  localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  return categories[index];
};

export const deleteCategory = (id: string): boolean => {
  const categories = getCategories();
  const filteredCategories = categories.filter(c => c.id !== id);
  if (filteredCategories.length === categories.length) return false;
  
  localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(filteredCategories));
  return true;
};

// Ad banner management
export const getAdBanners = (): AdBanner[] => {
  initializeSampleData();
  const banners = localStorage.getItem(STORAGE_KEYS.AD_BANNERS);
  return banners ? JSON.parse(banners) : [];
};

export const getActiveBanners = (): AdBanner[] => {
  return getAdBanners().filter(banner => banner.isActive);
};

export const addAdBanner = (banner: Omit<AdBanner, 'id' | 'createdAt' | 'updatedAt'>): AdBanner => {
  const banners = getAdBanners();
  const newBanner: AdBanner = {
    ...banner,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  banners.push(newBanner);
  localStorage.setItem(STORAGE_KEYS.AD_BANNERS, JSON.stringify(banners));
  return newBanner;
};

export const updateAdBanner = (id: string, updates: Partial<AdBanner>): AdBanner | null => {
  const banners = getAdBanners();
  const index = banners.findIndex(b => b.id === id);
  if (index === -1) return null;
  
  banners[index] = { ...banners[index], ...updates, updatedAt: new Date().toISOString() };
  localStorage.setItem(STORAGE_KEYS.AD_BANNERS, JSON.stringify(banners));
  return banners[index];
};

export const deleteAdBanner = (id: string): boolean => {
  const banners = getAdBanners();
  const filteredBanners = banners.filter(b => b.id !== id);
  if (filteredBanners.length === banners.length) return false;
  
  localStorage.setItem(STORAGE_KEYS.AD_BANNERS, JSON.stringify(filteredBanners));
  return true;
};

// Admin statistics
export const getAdminStats = () => {
  const businesses = getBusinesses();
  const categories = getCategories();
  const reviews = getReviews();
  const banners = getAdBanners();
  
  return {
    totalBusinesses: businesses.length,
    featuredBusinesses: businesses.filter(b => b.featured).length,
    totalCategories: categories.length,
    totalReviews: reviews.length,
    activeBanners: banners.filter(b => b.isActive).length,
    totalBanners: banners.length
  };
};
