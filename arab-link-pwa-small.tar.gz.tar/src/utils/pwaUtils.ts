// PWA Utility functions

export const isPWAInstalled = (): boolean => {
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
  const isInWebApp = (window.navigator as any).standalone === true;
  return isStandalone || isInWebApp;
};

export const isOnline = (): boolean => {
  return navigator.onLine;
};

export const cacheBusinessData = (businesses: any[]) => {
  if ('caches' in window) {
    caches.open('arab-link-data-v1').then(cache => {
      cache.put('/api/businesses', new Response(JSON.stringify(businesses)));
    });
  }
};

export const getCachedBusinessData = async (): Promise<any[] | null> => {
  if ('caches' in window) {
    const cache = await caches.open('arab-link-data-v1');
    const response = await cache.match('/api/businesses');
    if (response) {
      return await response.json();
    }
  }
  return null;
};

export const showInstallPrompt = (): boolean => {
  const hasBeenDismissed = sessionStorage.getItem('pwa-install-dismissed');
  const isInstalled = isPWAInstalled();
  return !hasBeenDismissed && !isInstalled;
};

export const trackPWAInstall = () => {
  // Analytics tracking for PWA installation
  console.log('PWA installed');
  if (typeof gtag !== 'undefined') {
    gtag('event', 'pwa_install', {
      event_category: 'PWA',
      event_label: 'App Installed'
    });
  }
};

export const trackOfflineUsage = () => {
  // Track offline usage
  console.log('App used offline');
  if (typeof gtag !== 'undefined') {
    gtag('event', 'offline_usage', {
      event_category: 'PWA',
      event_label: 'Offline Usage'
    });
  }
};

export const registerPWAListeners = () => {
  // Listen for app installation
  window.addEventListener('appinstalled', (evt) => {
    trackPWAInstall();
  });

  // Listen for online/offline events
  window.addEventListener('offline', () => {
    trackOfflineUsage();
  });

  // Listen for updates
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      window.location.reload();
    });
  }
};