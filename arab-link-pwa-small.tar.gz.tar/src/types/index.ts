export interface Business {
  id: string;
  name: string;
  category: string;
  subcategory: string;
  description: string;
  address: string;
  city: string;
  country: string;
  phone: string;
  email?: string;
  website?: string;
  hours: {
    [key: string]: string;
  };
  rating: number;
  reviewCount: number;
  priceRange: '$' | '$$' | '$$$' | '$$$$';
  images: string[];
  featured: boolean;
  verified: boolean;
  ownerId?: string;
  createdAt: string;
  updatedAt: string;
  latitude?: number;
  longitude?: number;
}

export interface Review {
  id: string;
  businessId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  images?: string[];
  createdAt: string;
  helpful: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  isBusinessOwner: boolean;
  favorites: string[];
  reviews: string[];
  createdAt: string;
  isAdmin?: boolean;
}

export interface Category {
  id: string;
  name: string;
  subcategories: string[];
  createdAt: string;
  updatedAt: string;
}

export interface AdBanner {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  linkUrl?: string;
  businessId?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SearchFilters {
  category?: string;
  city?: string;
  country?: string;
  rating?: number;
  priceRange?: string[];
  distance?: number;
  isOpen?: boolean;
}

export const CATEGORIES = {
  'healthcare': {
    name: 'Healthcare',
    subcategories: ['General Practice', 'Dentistry', 'Cardiology', 'Pediatrics', 'Dermatology', 'Psychology']
  },
  'restaurants': {
    name: 'Restaurants & Food',
    subcategories: ['Arabic Cuisine', 'Middle Eastern', 'Lebanese', 'Syrian', 'Egyptian', 'Fast Food', 'Delivery']
  },
  'legal': {
    name: 'Legal Services',
    subcategories: ['Immigration Law', 'Family Law', 'Business Law', 'Real Estate Law', 'Criminal Law']
  },
  'retail': {
    name: 'Retail & Shopping',
    subcategories: ['Halal Food', 'Arabic Books', 'Clothing', 'Electronics', 'Home Goods', 'Jewelry']
  },
  'services': {
    name: 'Services',
    subcategories: ['Translation', 'Real Estate', 'Financial Services', 'Travel Agency', 'Car Services', 'Beauty']
  },
  'education': {
    name: 'Education',
    subcategories: ['Arabic Schools', 'Quran Classes', 'Tutoring', 'Language Classes', 'Universities']
  },
  'religious': {
    name: 'Religious',
    subcategories: ['Mosques', 'Islamic Centers', 'Halal Certification', 'Religious Supplies']
  },
  'entertainment': {
    name: 'Entertainment',
    subcategories: ['Cultural Centers', 'Events', 'Music', 'Sports', 'Recreation']
  }
};

export const EUROPEAN_CITIES = [
  'London', 'Paris', 'Berlin', 'Madrid', 'Rome', 'Amsterdam', 'Brussels', 'Vienna',
  'Stockholm', 'Copenhagen', 'Dublin', 'Zurich', 'Geneva', 'Milan', 'Barcelona',
  'Munich', 'Hamburg', 'Frankfurt', 'Cologne', 'Lyon', 'Marseille', 'Naples',
  'Rotterdam', 'The Hague', 'Antwerp', 'Prague', 'Budapest', 'Warsaw', 'Oslo'
];