import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { getActiveBanners, getBusiness } from '@/lib/storage';
import { ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

const AdBanner = () => {
  const activeBanners = getActiveBanners();

  if (activeBanners.length === 0) {
    return null;
  }

  // Show the first active banner
  const banner = activeBanners[0];
  const linkedBusiness = banner.businessId ? getBusiness(banner.businessId) : null;

  const handleClick = () => {
    if (banner.linkUrl) {
      window.open(banner.linkUrl, '_blank');
    } else if (linkedBusiness) {
      // Navigate to business detail page
      window.location.href = `/business/${linkedBusiness.id}`;
    }
  };

  return (
    <Card className="mb-8 overflow-hidden bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
      <div className="relative">
        <img 
          src={banner.imageUrl} 
          alt={banner.title}
          className="w-full h-48 md:h-32 object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center">
          <div className="p-6 text-white">
            <h2 className="text-2xl md:text-3xl font-bold mb-2">{banner.title}</h2>
            <p className="text-lg mb-4 opacity-90">{banner.description}</p>
            {(banner.linkUrl || linkedBusiness) && (
              <Button 
                onClick={handleClick}
                variant="secondary"
                className="bg-white text-blue-600 hover:bg-gray-100"
              >
                {linkedBusiness ? 'View Business' : 'Learn More'}
                <ExternalLink className="ml-2 h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
};

export default AdBanner;