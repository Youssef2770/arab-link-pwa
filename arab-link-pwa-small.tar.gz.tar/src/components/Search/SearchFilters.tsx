import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Filter, X } from 'lucide-react';
import { SearchFilters as SearchFiltersType, CATEGORIES, EUROPEAN_CITIES } from '@/types';

interface SearchFiltersProps {
  filters: SearchFiltersType;
  onFiltersChange: (filters: SearchFiltersType) => void;
  onClearFilters: () => void;
}

export function SearchFilters({ filters, onFiltersChange, onClearFilters }: SearchFiltersProps) {
  const [isOpen, setIsOpen] = useState(false);

  const updateFilter = (key: keyof SearchFiltersType, value: string | number | string[] | boolean | undefined) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const togglePriceRange = (price: string) => {
    const current = filters.priceRange || [];
    const updated = current.includes(price)
      ? current.filter(p => p !== price)
      : [...current, price];
    updateFilter('priceRange', updated);
  };

  const getActiveFiltersCount = () => {
    let count = 0;
    if (filters.category) count++;
    if (filters.city) count++;
    if (filters.country) count++;
    if (filters.rating) count++;
    if (filters.priceRange?.length) count++;
    if (filters.distance) count++;
    if (filters.isOpen) count++;
    return count;
  };

  const activeCount = getActiveFiltersCount();

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" className="relative">
          <Filter className="h-4 w-4 mr-2" />
          Filters
          {activeCount > 0 && (
            <Badge className="ml-2 h-5 w-5 p-0 flex items-center justify-center text-xs">
              {activeCount}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      
      <SheetContent side="left" className="w-[300px] sm:w-[400px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Filter Results</SheetTitle>
          <SheetDescription>
            Narrow down your search to find exactly what you're looking for.
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Category Filter */}
          <div>
            <Label className="text-base font-medium">Category</Label>
            <Select value={filters.category || ''} onValueChange={(value) => updateFilter('category', value || undefined)}>
              <SelectTrigger className="w-full mt-2">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {Object.entries(CATEGORIES).map(([key, category]) => (
                  <SelectItem key={key} value={key}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Location Filters */}
          <div>
            <Label className="text-base font-medium">Location</Label>
            <div className="space-y-2 mt-2">
              <Select value={filters.city || ''} onValueChange={(value) => updateFilter('city', value || undefined)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select city" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cities</SelectItem>
                  {EUROPEAN_CITIES.map((city) => (
                    <SelectItem key={city} value={city}>
                      {city}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Rating Filter */}
          <div>
            <Label className="text-base font-medium">Minimum Rating</Label>
            <Select value={filters.rating?.toString() || ''} onValueChange={(value) => updateFilter('rating', value ? parseInt(value) : undefined)}>
              <SelectTrigger className="w-full mt-2">
                <SelectValue placeholder="Any rating" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any Rating</SelectItem>
                <SelectItem value="4">4+ Stars</SelectItem>
                <SelectItem value="3">3+ Stars</SelectItem>
                <SelectItem value="2">2+ Stars</SelectItem>
                <SelectItem value="1">1+ Stars</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Price Range Filter */}
          <div>
            <Label className="text-base font-medium">Price Range</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {['$', '$$', '$$$', '$$$$'].map((price) => (
                <div key={price} className="flex items-center space-x-2">
                  <Checkbox
                    id={`price-${price}`}
                    checked={filters.priceRange?.includes(price) || false}
                    onCheckedChange={() => togglePriceRange(price)}
                  />
                  <Label htmlFor={`price-${price}`} className="text-sm">
                    {price} {price === '$' && '(Budget)'}
                    {price === '$$' && '(Moderate)'}
                    {price === '$$$' && '(Expensive)'}
                    {price === '$$$$' && '(Luxury)'}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          {/* Distance Filter */}
          <div>
            <Label htmlFor="distance" className="text-base font-medium">
              Distance (km)
            </Label>
            <Input
              id="distance"
              type="number"
              placeholder="Max distance"
              value={filters.distance || ''}
              onChange={(e) => updateFilter('distance', e.target.value ? parseInt(e.target.value) : undefined)}
              className="mt-2"
              min="1"
              max="100"
            />
          </div>

          {/* Open Now Filter */}
          <div className="flex items-center space-x-2">
            <Checkbox
              id="open-now"
              checked={filters.isOpen || false}
              onCheckedChange={(checked) => updateFilter('isOpen', checked)}
            />
            <Label htmlFor="open-now" className="text-base font-medium">
              Open Now
            </Label>
          </div>

          {/* Active Filters */}
          {activeCount > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-base font-medium">Active Filters</Label>
                <Button variant="ghost" size="sm" onClick={onClearFilters}>
                  Clear All
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {filters.category && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    {CATEGORIES[filters.category]?.name}
                    <X 
                      className="h-3 w-3 cursor-pointer" 
                      onClick={() => updateFilter('category', undefined)}
                    />
                  </Badge>
                )}
                {filters.city && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    {filters.city}
                    <X 
                      className="h-3 w-3 cursor-pointer" 
                      onClick={() => updateFilter('city', undefined)}
                    />
                  </Badge>
                )}
                {filters.rating && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    {filters.rating}+ Stars
                    <X 
                      className="h-3 w-3 cursor-pointer" 
                      onClick={() => updateFilter('rating', undefined)}
                    />
                  </Badge>
                )}
                {filters.priceRange?.map((price) => (
                  <Badge key={price} variant="secondary" className="flex items-center gap-1">
                    {price}
                    <X 
                      className="h-3 w-3 cursor-pointer" 
                      onClick={() => togglePriceRange(price)}
                    />
                  </Badge>
                ))}
                {filters.distance && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    {filters.distance}km
                    <X 
                      className="h-3 w-3 cursor-pointer" 
                      onClick={() => updateFilter('distance', undefined)}
                    />
                  </Badge>
                )}
                {filters.isOpen && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    Open Now
                    <X 
                      className="h-3 w-3 cursor-pointer" 
                      onClick={() => updateFilter('isOpen', false)}
                    />
                  </Badge>
                )}
              </div>
            </div>
          )}

          <div className="flex gap-2 pt-4">
            <Button onClick={() => setIsOpen(false)} className="flex-1">
              Apply Filters
            </Button>
            <Button variant="outline" onClick={onClearFilters}>
              Clear
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}