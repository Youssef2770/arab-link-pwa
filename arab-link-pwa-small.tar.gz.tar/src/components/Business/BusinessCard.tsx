import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, MapPin, Phone, Clock, Heart } from 'lucide-react';
import { Business } from '@/types';
import { isFavorite, addToFavorites, removeFromFavorites, getCurrentUser } from '@/lib/storage';
import { toast } from 'sonner';
import { useState } from 'react';

interface BusinessCardProps {
  business: Business;
}

export function BusinessCard({ business }: BusinessCardProps) {
  const [favorite, setFavorite] = useState(isFavorite(business.id));
  const user = getCurrentUser();

  const handleFavoriteToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!user) {
      toast.error('Please sign in to add favorites');
      return;
    }

    if (favorite) {
      removeFromFavorites(business.id);
      setFavorite(false);
      toast.success('Removed from favorites');
    } else {
      addToFavorites(business.id);
      setFavorite(true);
      toast.success('Added to favorites');
    }
  };

  const getPriceRangeText = (priceRange: string) => {
    switch (priceRange) {
      case '$': return 'Budget-friendly';
      case '$$': return 'Moderate';
      case '$$$': return 'Expensive';
      case '$$$$': return 'Very Expensive';
      default: return 'Price not specified';
    }
  };

  const isOpen = () => {
    const now = new Date();
    const day = now.toLocaleDateString('en-US', { weekday: 'long' });
    const currentHours = business.hours[day];
    
    if (!currentHours || currentHours === 'Closed') return false;
    
    const currentTime = now.getHours() * 100 + now.getMinutes();
    const [openTime, closeTime] = currentHours.split(' - ').map(time => {
      const [hour, minute] = time.replace(/[^\d:]/g, '').split(':').map(Number);
      const isPM = time.toLowerCase().includes('pm');
      const adjustedHour = isPM && hour !== 12 ? hour + 12 : (!isPM && hour === 12 ? 0 : hour);
      return adjustedHour * 100 + (minute || 0);
    });
    
    return currentTime >= openTime && currentTime <= closeTime;
  };

  return (
    <Link to={`/business/${business.id}`}>
      <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer group">
        <div className="relative">
          <img
            src={business.images[0] || '/api/placeholder/400/200'}
            alt={business.name}
            className="w-full h-48 object-cover rounded-t-lg"
          />
          <div className="absolute top-2 left-2 flex gap-1">
            {business.featured && (
              <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                Featured
              </Badge>
            )}
            {business.verified && (
              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                Verified
              </Badge>
            )}
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-2 right-2 h-8 w-8 p-0 bg-white/80 hover:bg-white"
            onClick={handleFavoriteToggle}
          >
            <Heart className={`h-4 w-4 ${favorite ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
          </Button>
        </div>
        
        <CardContent className="p-4">
          <div className="space-y-2">
            <div className="flex items-start justify-between">
              <h3 className="font-semibold text-lg group-hover:text-blue-600 transition-colors">
                {business.name}
              </h3>
              <div className="flex items-center gap-1 text-sm">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span className="font-medium">{business.rating}</span>
                <span className="text-gray-500">({business.reviewCount})</span>
              </div>
            </div>
            
            <p className="text-sm text-gray-600 line-clamp-2">{business.description}</p>
            
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <MapPin className="h-4 w-4" />
              <span>{business.city}, {business.country}</span>
            </div>
            
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Phone className="h-4 w-4" />
              <span>{business.phone}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-gray-400" />
                <span className={`text-sm font-medium ${isOpen() ? 'text-green-600' : 'text-red-600'}`}>
                  {isOpen() ? 'Open Now' : 'Closed'}
                </span>
              </div>
              <Badge variant="outline" className="text-xs">
                {getPriceRangeText(business.priceRange)}
              </Badge>
            </div>
            
            <div className="flex gap-1 flex-wrap">
              <Badge variant="secondary" className="text-xs">
                {business.subcategory}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}