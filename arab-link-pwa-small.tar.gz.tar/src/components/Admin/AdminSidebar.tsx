import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { 
  LayoutDashboard, 
  Building2, 
  FolderTree, 
  Megaphone, 
  LogOut,
  Settings
} from 'lucide-react';
import { logoutUser } from '@/lib/storage';

const AdminSidebar = () => {
  const location = useLocation();
  
  const menuItems = [
    { path: '/admin', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/admin/businesses', label: 'Businesses', icon: Building2 },
    { path: '/admin/categories', label: 'Categories', icon: FolderTree },
    { path: '/admin/ads', label: 'Advertising', icon: Megaphone },
  ];

  const handleLogout = () => {
    logoutUser();
    window.location.href = '/';
  };

  return (
    <Card className="w-64 h-screen p-6 border-r bg-gray-50">
      <div className="mb-8">
        <h2 className="text-xl font-bold text-gray-800">Admin Panel</h2>
        <p className="text-sm text-gray-600">Arab Link Management</p>
      </div>
      
      <nav className="space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <Link key={item.path} to={item.path}>
              <Button
                variant={isActive ? "default" : "ghost"}
                className={`w-full justify-start ${isActive ? 'bg-blue-600 text-white' : ''}`}
              >
                <Icon className="mr-3 h-4 w-4" />
                {item.label}
              </Button>
            </Link>
          );
        })}
      </nav>
      
      <div className="absolute bottom-6 left-6 right-6">
        <Button
          onClick={handleLogout}
          variant="outline"
          className="w-full justify-start text-red-600 border-red-200 hover:bg-red-50"
        >
          <LogOut className="mr-3 h-4 w-4" />
          Logout
        </Button>
      </div>
    </Card>
  );
};

export default AdminSidebar;