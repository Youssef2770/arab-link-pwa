# Arab Link PWA - دليل الأعمال العربية

🚀 **تطبيق ويب تقدمي (PWA) لدليل الأعمال العربية في أوروبا**

![Arab Link Logo](public/logo.png)

## 📱 نظرة عامة / Overview

**العربية:**
Arab Link هو تطبيق ويب تقدمي (PWA) يهدف إلى ربط المجتمع العربي في أوروبا بالأعمال والخدمات المحلية. يوفر التطبيق دليلاً شاملاً للمطاعم والعيادات والخدمات القانونية وأكثر.

**English:**
Arab Link is a Progressive Web App (PWA) designed to connect the Arab community in Europe with local businesses and services. The app provides a comprehensive directory of restaurants, clinics, legal services, and more.

## ✨ الميزات / Features

### 🌟 للمستخدمين / For Users
- 📱 **PWA قابل للتثبيت** / Installable PWA
- 🔍 **بحث متقدم وفلترة** / Advanced search and filtering
- 💙 **قائمة المفضلة** / Favorites list
- 🌐 **دعم العربية RTL** / Arabic RTL support
- 📴 **عمل بدون إنترنت** / Offline functionality
- 🎯 **إعلانات مستهدفة** / Targeted advertisements

### 👨‍💼 للإدارة / For Administrators
- 🛠️ **لوحة إدارة شاملة** / Comprehensive admin dashboard
- 🏪 **إدارة الأعمال** / Business management
- 📂 **إدارة الفئات** / Category management
- 🎨 **إدارة الإعلانات** / Advertisement management
- 📊 **إحصائيات وتقارير** / Statistics and reports

## 🛠️ التقنيات المستخدمة / Tech Stack

- **Frontend:** React 18 + TypeScript
- **UI Framework:** Shadcn-ui + Tailwind CSS
- **Build Tool:** Vite
- **PWA:** Service Worker + Web App Manifest
- **Storage:** localStorage (قابل للترقية إلى Firebase)
- **Routing:** React Router
- **Icons:** Lucide React

## 🚀 التثبيت والتشغيل / Installation & Setup

### المتطلبات / Prerequisites
- Node.js 18+ 
- pnpm (recommended) or npm

### خطوات التثبيت / Installation Steps

```bash
# استنساخ المشروع / Clone the repository
git clone https://github.com/yourusername/arab-link-pwa.git
cd arab-link-pwa

# تثبيت المعتمدات / Install dependencies
pnpm install

# تشغيل الخادم المحلي / Start development server
pnpm run dev

# بناء للإنتاج / Build for production
pnpm run build

# معاينة البناء / Preview production build
pnpm run preview
```

## 🔑 الوصول للإدارة / Admin Access

- **الرابط / URL:** `/admin/login`
- **البريد الإلكتروني / Email:** `admin@arablink.com`
- **كلمة المرور / Password:** `admin123`

## 📁 هيكل المشروع / Project Structure

```
src/
├── components/           # مكونات React / React Components
│   ├── Admin/           # لوحة الإدارة / Admin Dashboard
│   ├── Auth/            # المصادقة / Authentication
│   ├── Business/        # عرض الأعمال / Business Display
│   ├── Layout/          # تخطيط الصفحة / Page Layout
│   └── ui/              # مكونات UI / UI Components
├── pages/               # صفحات التطبيق / Application Pages
├── lib/                 # مكتبات مساعدة / Utility Libraries
├── hooks/               # React Hooks المخصصة
└── types/               # تعريفات TypeScript
```

## 🌐 النشر / Deployment

### Firebase Hosting
```bash
# تثبيت Firebase CLI / Install Firebase CLI
npm install -g firebase-tools

# تسجيل الدخول / Login to Firebase
firebase login

# ربط المشروع / Connect to project
firebase use your-project-id

# نشر التطبيق / Deploy application
firebase deploy --only hosting
```

### Hostinger
راجع دليل النشر المفصل في `HOSTINGER_DEPLOYMENT.md`
See detailed deployment guide in `HOSTINGER_DEPLOYMENT.md`

## 📱 اختبار PWA / PWA Testing

### على الهاتف / On Mobile
1. افتح الموقع في Chrome أو Safari
2. ابحث عن خيار "إضافة إلى الشاشة الرئيسية"
3. ثبت التطبيق واستخدمه كتطبيق عادي

### العمل بدون إنترنت / Offline Testing
1. افتح التطبيق
2. فعل وضع الطيران في الهاتف
3. يجب أن يعمل التطبيق بدون إنترنت

## 🤝 المساهمة / Contributing

1. Fork المشروع
2. أنشئ فرع للميزة الجديدة (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push إلى الفرع (`git push origin feature/amazing-feature`)
5. افتح Pull Request

## 📄 الرخصة / License

هذا المشروع مرخص تحت رخصة MIT - راجع ملف `LICENSE` للتفاصيل.

## 📞 الدعم / Support

لأي استفسارات أو مساعدة:
- 📧 Email: support@arablink.com
- 🌐 Website: https://arablink.com

## 🎯 التطورات المستقبلية / Future Enhancements

- [ ] تكامل خرائط Google / Google Maps Integration
- [ ] نظام التقييمات والمراجعات / Reviews & Ratings System
- [ ] تسجيل الأعمال الذاتي / Self Business Registration
- [ ] إشعارات فورية / Push Notifications
- [ ] تطبيق أندرويد/iOS أصلي / Native Android/iOS App

---

**صنع بـ ❤️ للمجتمع العربي في أوروبا**  
**Made with ❤️ for the Arab Community in Europe**